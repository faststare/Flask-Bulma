# Flask-Bulma

> UIkit for use in Flask

Usage
-----

Here is an example:
```
  from flask_bulma import Bulma

  [...]

  Bulma(app)
```

Reference
-----

[Flask-UIkit](https://github.com/kwkwc/flask-uikit/)
